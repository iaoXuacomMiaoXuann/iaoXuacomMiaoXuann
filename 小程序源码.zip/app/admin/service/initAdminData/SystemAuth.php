<?php
$ul_system_auth = array(
    array(
        "id" => 1,
        "title" => "管理员",
        "sort" => 1,
        "status" => 1,
        "remark" => "测试管理员",
    ),
    array(
        "id" => 6,
        "title" => "游客权限",
        "sort" => 0,
        "status" => 1,
        "remark" => "",

    )
);


return $ul_system_auth;
