<?php
$ul_mall_goods = array(
    array(
        "title" => "落地-风扇",
        "logo" => "http://admin.demo.ulthon.com/upload/20220417/72ef1d769595627af51d76c612a789bf.png",
        "images" => "http://admin.host/upload/20200514/95496713918290f6315ea3f87efa6bf2.jpg|http://admin.host/upload/20200514/ae29fa9cba4fc02defb7daed41cb2b13.jpg|http://admin.host/upload/20200514/f0a104d88ec7dc6fb42d2f87cbc71b76.jpg|http://admin.host/upload/20200514/3b88be4b1934690e5c1bd6b54b9ab5c8.jpg",
        "describe" => "&lt;p&gt;76654757&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;http://admin.host/upload/20200515/198070421110fa01f2c2ac2f52481647.jpg&quot; style=&quot;height:689px; width:790px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;http://admin.host/upload/20200515/a07a742c15a78781e79f8a3317006c1d.jpg&quot; style=&quot;height:877px; width:790px&quot; /&gt;&lt;/p&gt;\n",
        "market_price" => 599.00,
        "discount_price" => 368.00,
        "sales" => 0,
        "virtual_sales" => 594,
        "stock" => 0,
        "total_stock" => 0,
        "sort" => 675,
        "status" => 1,
        "remark" => "",
    ),
    array(
        "title" => "电脑",
        "logo" => "http://admin.demo.ulthon.com/upload/20220417/72ef1d769595627af51d76c612a789bf.png",
        "images" => "http://admin.host/upload/20200514/f0a104d88ec7dc6fb42d2f87cbc71b76.jpg",
        "describe" => "&lt;p&gt;477&lt;/p&gt;\n",
        "market_price" => 0.00,
        "discount_price" => 0.00,
        "sales" => 0,
        "virtual_sales" => 0,
        "stock" => 115,
        "total_stock" => 320,
        "sort" => 0,
        "status" => 1,
        "remark" => "",
    )
);
return $ul_mall_goods;
