<?php


namespace app\admin\service\curd\exceptions;


class TableException extends \Exception
{

}