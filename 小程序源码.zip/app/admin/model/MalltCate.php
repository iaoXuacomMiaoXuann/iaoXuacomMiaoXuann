<?php


namespace app\admin\model;


use app\common\model\TimeModel;
/**
 * 
 */
class MalltCate extends TimeModel
{

    protected $deleteTime = 'delete_time';

}