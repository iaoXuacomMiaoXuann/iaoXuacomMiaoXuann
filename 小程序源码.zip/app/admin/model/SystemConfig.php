<?php



namespace app\admin\model;


use app\common\model\TimeModel;

class SystemConfig extends TimeModel
{
    protected $deleteTime = false;
}