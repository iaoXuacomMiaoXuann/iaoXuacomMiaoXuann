<?php


namespace app\admin\model;


use app\common\model\TimeModel;

class SystemUploadfile extends TimeModel
{

}