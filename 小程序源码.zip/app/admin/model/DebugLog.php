<?php

namespace app\admin\model;

use app\common\model\TimeModel;

class DebugLog extends TimeModel
{

    protected $name = "debug_log";

    protected $deleteTime = false;

    
    

}