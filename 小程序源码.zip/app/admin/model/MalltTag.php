<?php

namespace app\admin\model;

use app\common\model\TimeModel;

class MalltTag extends TimeModel
{

    protected $name = "mallt_tag";

    protected $deleteTime = "delete_time";

    
    
    

}