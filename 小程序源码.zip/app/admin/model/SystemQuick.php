<?php


namespace app\admin\model;


use app\common\model\TimeModel;

class SystemQuick extends TimeModel
{

    protected $deleteTime = 'delete_time';

    public static $autoCache = [
        [
            'name' => 'welcome_list'
        ]
    ];
}
