<?php
declare (strict_types=1);

return [
    0 => 'think\\captcha\\CaptchaService',
    1 => 'think\\app\\Service',
];