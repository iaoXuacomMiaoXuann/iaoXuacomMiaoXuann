-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2023-06-17 22:26:22
-- 服务器版本： 5.7.26
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `ulthon`
--

-- --------------------------------------------------------

--
-- 表的结构 `ul_debug_log`
--

CREATE TABLE `ul_debug_log` (
  `id` int(11) NOT NULL,
  `uid` char(30) NOT NULL DEFAULT '',
  `level` char(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `create_time_title` char(30) NOT NULL DEFAULT '',
  `create_time` int(11) NOT NULL DEFAULT '0',
  `app_name` char(30) NOT NULL DEFAULT '',
  `controller_name` char(30) NOT NULL DEFAULT '',
  `action_name` char(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='日志表';

-- --------------------------------------------------------

--
-- 表的结构 `ul_flink`
--

CREATE TABLE `ul_flink` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='友情链接';

--
-- 转存表中的数据 `ul_flink`
--

INSERT INTO `ul_flink` (`id`, `name`, `url`) VALUES
(8, '创新博客', 'https://y.goolibao.com'),
(3, '阿里图标库', 'https://www.iconfont.cn/'),
(18, '免费源码下载', 'http://y.goolibao.com'),
(21, 'ChatGPT', 'https://y.goolibao.com/?keyword=chatgpt'),
(23, '网站案查询', 'https://ssl.goolibao.com/icp'),
(24, 'Favicon.ico图片在线制作系统', 'https://ssl.goolibao.com/ico'),
(25, 'AI网址导航', 'https://ai.goolibao.com/');

-- --------------------------------------------------------

--
-- 表的结构 `ul_mallt_cate`
--

CREATE TABLE `ul_mallt_cate` (
  `id` int(11) NOT NULL,
  `title` char(20) NOT NULL DEFAULT '' COMMENT '分类名',
  `image` char(255) NOT NULL DEFAULT '' COMMENT '分类图片 {image}',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` int(1) NOT NULL DEFAULT '2' COMMENT '状态 {radio} (1:禁用,2:启用)',
  `remark` char(255) NOT NULL DEFAULT '' COMMENT '备注说明',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `url` text NOT NULL COMMENT 'URL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品分类';

--
-- 转存表中的数据 `ul_mallt_cate`
--

INSERT INTO `ul_mallt_cate` (`id`, `title`, `image`, `sort`, `status`, `remark`, `create_time`, `update_time`, `delete_time`, `url`) VALUES
(18, 'AI导航', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'icon icon-nav-ai', 1685499568, 1685499745, 0, 'https://ai.goolibao.com'),
(19, 'SSL证书', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'icon icon-nav-hao-1', 1685499840, 1685499840, 0, 'http://ssl.goolibao.com');

-- --------------------------------------------------------

--
-- 表的结构 `ul_mall_cate`
--

CREATE TABLE `ul_mall_cate` (
  `id` int(11) NOT NULL,
  `title` char(20) NOT NULL DEFAULT '' COMMENT '分类名',
  `image` char(255) NOT NULL DEFAULT '' COMMENT '分类图片 {image}',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` int(1) NOT NULL DEFAULT '2' COMMENT '状态 {radio} (1:禁用,2:启用)',
  `remark` char(255) NOT NULL DEFAULT '' COMMENT '备注说明',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `url` text NOT NULL COMMENT 'URL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品分类';

--
-- 转存表中的数据 `ul_mall_cate`
--

INSERT INTO `ul_mall_cate` (`id`, `title`, `image`, `sort`, `status`, `remark`, `create_time`, `update_time`, `delete_time`, `url`) VALUES
(2, '国内推荐', '/storage/upload/20230530/6476128e23b5d.png', 0, 2, 'ico icon-icon-group-hot', 1685459601, 1685469372, 0, '#hot'),
(3, '聊天AI', '/storage/upload/20230530/647612c88b565.png', 0, 2, 'ico icon-message', 1685459658, 1685469365, 0, '#smart2'),
(4, '绘画AI', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-i-illustration', 1685459702, 1685469353, 0, '#smart'),
(5, ' AI提示词', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-nav-hot-1', 1685469069, 1685469344, 0, '#smart4'),
(6, ' 图像处理', '/storage/upload/20230530/6476128e23b5d.png', 0, 2, 'ico icon-i-img', 1685469238, 1685469332, 0, '#smart9'),
(7, ' UI设计', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-nav-icon-7', 1685469324, 1685469324, 0, '#smart7'),
(8, ' 3D设计', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-i-c4d', 1685469435, 1685469435, 0, '#smart5'),
(9, '平面设计', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-graphic', 1685469493, 1685469493, 0, '#smart8'),
(10, ' 智能写作', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-article-2', 1685469528, 1685469528, 0, '#smart6'),
(11, ' 音视频', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-nav-icon-21', 1685469603, 1685469603, 0, '#smart10'),
(12, ' AI学习', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-nav-uiii-1', 1685469640, 1685469640, 0, '#study'),
(13, ' AI办公', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-nav-icon-5', 1685469690, 1685469690, 0, '#gadget'),
(14, ' AI编程', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-nav-icon-2', 1685469727, 1685469727, 0, '#program'),
(15, ' AI研究', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-nav-hao-2', 1685469771, 1685469771, 0, '#institution'),
(16, '站长工具', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-fans', 1685469878, 1685471732, 0, '#smart12'),
(17, ' 探索更多', '/storage/upload/20230530/647612f50faf4.png', 0, 2, 'ico icon-nav-icon-13', 1685469914, 1685469914, 0, '#smart11');

-- --------------------------------------------------------

--
-- 表的结构 `ul_mall_goods`
--

CREATE TABLE `ul_mall_goods` (
  `id` int(11) NOT NULL,
  `cate_id` bigint(20) UNSIGNED NOT NULL COMMENT '分类ID',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '商品名称',
  `tag` char(100) NOT NULL DEFAULT '' COMMENT '商品标签',
  `logo` char(255) NOT NULL COMMENT '商品logo {image}',
  `images` text NOT NULL COMMENT '商品图片 {images}',
  `describe` text NOT NULL COMMENT '商品描述 {editor}',
  `property` text NOT NULL COMMENT '商品属性',
  `market_price` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '市场价',
  `discount_price` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '折扣价',
  `sales` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '销量',
  `virtual_sales` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '虚拟销量',
  `stock` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '库存',
  `total_stock` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '总库存',
  `sort` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '排序',
  `status` int(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '状态 {radio} (0:正常,1:禁用)',
  `remark` char(255) NOT NULL DEFAULT '' COMMENT '备注说明',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `license` varchar(100) NOT NULL COMMENT '授权文件 {file}',
  `license_name` varchar(100) NOT NULL COMMENT '授权文件名称'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品列表';

--
-- 转存表中的数据 `ul_mall_goods`
--

INSERT INTO `ul_mall_goods` (`id`, `cate_id`, `title`, `tag`, `logo`, `images`, `describe`, `property`, `market_price`, `discount_price`, `sales`, `virtual_sales`, `stock`, `total_stock`, `sort`, `status`, `remark`, `create_time`, `update_time`, `delete_time`, `license`, `license_name`) VALUES
(1, 1, '1111', '', '111', '111', '', '', '0.00', '0.00', 0, 0, 0, 0, 0, 0, '1111', 1685457999, 1685459780, 1685459780, '1111', '1111'),
(2, 2, 'Notion AI', '', '/storage/upload/20230530/647613a8291da.ico', '/storage/upload/20230530/647613c2b603c.jpg', 'Notion旗下的AI笔记和内容创作助手', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://www.notion.so/product/ai', 1685459996, 1685516570, 0, '11', '11'),
(3, 2, 'Midjourney', '', '/storage/upload/20230531/6476ed6c309ee.png', '/storage/upload/20230530/647613c2b603c.jpg', '目前最强的AI绘画工具\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://www.midjourney.com/', 1685515536, 1685515900, 0, '111', '111'),
(4, 2, 'ChatGPT', '', 'http://127.0.0.3/storage/upload/20230531/6476edc3a0c86.png', '/storage/upload/20230530/647613c2b603c.jpg', '地表最强AI聊天机器人', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://chat.openai.com/', 1685515777, 1685515898, 0, '11', '11'),
(5, 2, ' Stable Diffusion', '', '/storage/upload/20230531/6476ee443642f.png', '/storage/upload/20230530/647613c2b603c.jpg', '目前最强的AI绘画工具\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://www.midjourney.com/', 1685515893, 1685515893, 0, '11', '11'),
(6, 2, ' NijiJourney', '', '/storage/upload/20230531/6476eee1b4523.png', '/storage/upload/20230530/647613c2b603c.jpg', 'MJ出品！面向二次元风格，内容细致拿捏专业到位\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://nijijourney.com/zh/', 1685516038, 1685516042, 0, '11', '11'),
(7, 2, 'Microsoft Designer', '', 'http://127.0.0.3/storage/upload/20230531/6476ef407cfd1.png', '/storage/upload/20230530/647613c2b603c.jpg', '微软推出的AI平面设计工具，实现快速完成设计加工\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://designer.microsoft.com/', 1685516146, 1685516146, 0, '11', '11'),
(8, 2, ' HuggingFace', '', 'http://127.0.0.3/storage/upload/20230531/6476efb8bf585.png', '/storage/upload/20230530/647613c2b603c.jpg', '这是一个开源SD模型\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://huggingface.co/', 1685516259, 1685516277, 0, '11', '11'),
(9, 2, ' SaaS AI Tools', '', 'http://127.0.0.3/storage/upload/20230531/6476f04b72a3b.png', '/storage/upload/20230530/647613c2b603c.jpg', '推荐！超多AI人工智能工具', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://saasaitools.com/', 1685516404, 1685516404, 0, '11', '11'),
(10, 2, ' PromptHero', '', '/storage/upload/20230531/6476f1c3f10ab.png', '/storage/upload/20230530/647613c2b603c.jpg', '推荐！最受欢迎的AI提示词网站\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://prompthero.com/', 1685516784, 1685516784, 0, '11', '11'),
(11, 2, 'Vectorizer', '', '/storage/upload/20230531/6476f23c714fd.png', '/storage/upload/20230530/647613c2b603c.jpg', '免费使用！一键将位图转为矢量图\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://vectorizer.ai/', 1685516892, 1685516892, 0, '11', '11'),
(12, 2, 'Runway', '', 'http://127.0.0.3/storage/upload/20230531/6476f27e3dfb3.png', '/storage/upload/20230530/647613c2b603c.jpg', '最强的AI视频内容生成工具\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://runwayml.com/', 1685516970, 1685516970, 0, '11', '11'),
(13, 2, 'SSL证书在线生成', '', 'http://127.0.0.3/storage/upload/20230531/6476f2f875207.png', '/storage/upload/20230530/647613c2b603c.jpg', '国内首个无需登陆就可以在线生成ssl证书的工具', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://ssl.goolibao.com', 1685517086, 1685517086, 0, '11', '11'),
(14, 3, 'ChatGPT', '', '/storage/upload/20230531/6476f71aa9996.png', '/storage/upload/20230530/647613c2b603c.jpg', '地表最强AI聊天机器人', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://chat.openai.com/', 1685518127, 1685518127, 0, '11', '11'),
(15, 3, ' Anthropic', '', '/storage/upload/20230531/6476f7497c855.png', '/storage/upload/20230530/647613c2b603c.jpg', 'Anthropic发布的与ChatGPT竞争的聊天机器人\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://www.anthropic.com/', 1685518187, 1685518215, 0, '11', '11'),
(16, 3, ' OpenCat', '', 'http://127.0.0.3/storage/upload/20230531/6476f7f905943.png', '/storage/upload/20230530/647613c2b603c.jpg', '在苹果手表上用ChatGPT', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://apps.apple.com/us/app/opencat/id6445999201', 1685518363, 1685518363, 0, '11', '11'),
(17, 3, ' NewBing', '', '/storage/upload/20230531/6476f841d6aa0.png', '/storage/upload/20230530/647613c2b603c.jpg', 'Bing版ChatGPT聊天机器人，微软新搜索引擎', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://www.bing.com/new', 1685518456, 1685518456, 0, '11', '11'),
(18, 3, '通义千问', '', 'http://127.0.0.3/storage/upload/20230531/6476f8a35337e.png', '/storage/upload/20230530/647613c2b603c.jpg', '阿里巴巴的AI对话机器人', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://tongyi.aliyun.com/', 1685518530, 1685518530, 0, '11', '11'),
(19, 3, ' YOU', '', 'http://127.0.0.3/storage/upload/20230531/6476f916f002e.png', '/storage/upload/20230530/647613c2b603c.jpg', '人工智能搜索聊天机器人', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://you.com/', 1685518641, 1685518641, 0, '11', '11'),
(20, 4, 'Midjourney', '', '/storage/upload/20230531/64770a3bee6a7.png', '/storage/upload/20230530/647613c2b603c.jpg', '目前最强的AI绘画工具', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://www.midjourney.com/', 1685523037, 1685523037, 0, '11', '11'),
(21, 4, ' Stable Diffusion', '', '/storage/upload/20230531/64770a77be545.png', '/storage/upload/20230530/647613c2b603c.jpg', '最强开源AI绘画工具', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://github.com/Stability-AI/stablediffusion', 1685523145, 1685523145, 0, '11', '11'),
(22, 4, ' 文心一格', '', '/storage/upload/20230531/64770b0f6c540.png', '/storage/upload/20230530/647613c2b603c.jpg', '百度出品的AI绘画工具\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://yige.baidu.com/', 1685523245, 1685523542, 0, '11', '11'),
(23, 4, ' Dreamlike.art', '', '/storage/upload/20230531/64770b5084823.png', '/storage/upload/20230530/647613c2b603c.jpg', '效果惊人！内置5种模型的AI图像生成器\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://dreamlike.art/create', 1685523319, 1685523525, 0, '11', '11'),
(24, 4, ' DALL·E2', '', '/storage/upload/20230531/64770ba57f365.png', '/storage/upload/20230530/647613c2b603c.jpg', 'OpenAI出品的绘画工具\n', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://openai.com/research/dall-e', 1685523391, 1685523512, 0, '11', '11'),
(25, 4, ' HuggingFace', '', '/storage/upload/20230531/64770bfaad411.png', '/storage/upload/20230530/647613c2b603c.jpg', '下载开源的SD模型', '', '0.00', '0.00', 0, 0, 0, 0, 1, 0, 'https://huggingface.co/', 1685523482, 1685523482, 0, '1', '1');

-- --------------------------------------------------------

--
-- 表的结构 `ul_mall_tag`
--

CREATE TABLE `ul_mall_tag` (
  `id` int(11) NOT NULL,
  `title` char(20) NOT NULL DEFAULT '' COMMENT '商品名称',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品标签';

-- --------------------------------------------------------

--
-- 表的结构 `ul_migrations`
--

CREATE TABLE `ul_migrations` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ul_migrations`
--

INSERT INTO `ul_migrations` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
(20220419022952, 'SystemAdmin', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419030557, 'SystemAuth', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419031101, 'SystemAuthNode', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419031527, 'SystemConfig', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419032028, 'SystemMenu', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419032642, 'SystemNode', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419033507, 'SystemQuick', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419034810, 'SystemUploadfile', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419102226, 'DebugLog', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419102635, 'MallCate', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220419102916, 'MallGoods', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220709061205, 'MallTag', '2023-05-30 14:40:07', '2023-05-30 14:40:07', 0),
(20220905222557, 'TestGoods', '2023-05-30 14:40:07', '2023-05-30 14:40:08', 0);

-- --------------------------------------------------------

--
-- 表的结构 `ul_system_admin`
--

CREATE TABLE `ul_system_admin` (
  `id` int(11) NOT NULL,
  `auth_ids` char(255) NOT NULL DEFAULT '' COMMENT '角色权限ID',
  `head_img` char(255) NOT NULL DEFAULT '' COMMENT '头像',
  `username` char(50) NOT NULL DEFAULT '' COMMENT '用户登录名',
  `password` char(40) NOT NULL DEFAULT '' COMMENT '用户密码',
  `phone` char(16) NOT NULL DEFAULT '' COMMENT '联系手机号',
  `remark` char(255) NOT NULL DEFAULT '' COMMENT '备注说明',
  `login_num` bigint(20) UNSIGNED NOT NULL DEFAULT '0' COMMENT '登录次数',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` int(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT '状态 {radio} (0:禁用,1:启用,)',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统用户表';

--
-- 转存表中的数据 `ul_system_admin`
--

INSERT INTO `ul_system_admin` (`id`, `auth_ids`, `head_img`, `username`, `password`, `phone`, `remark`, `login_num`, `sort`, `status`, `create_time`, `update_time`, `delete_time`) VALUES
(1, '', 'http://127.0.0.3/storage/upload/20230531/64775f5209841.png', 'admin', 'ac1e198122f74121a69b7bc9048561973a433daa', '', '', 15, 0, 1, 1685457618, 1687004890, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ul_system_auth`
--

CREATE TABLE `ul_system_auth` (
  `id` int(11) NOT NULL,
  `title` char(20) NOT NULL COMMENT '权限名称',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '状态 {radio} (1:禁用,2:启用)',
  `remark` char(255) NOT NULL DEFAULT '' COMMENT '备注说明',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统权限表';

--
-- 转存表中的数据 `ul_system_auth`
--

INSERT INTO `ul_system_auth` (`id`, `title`, `sort`, `status`, `remark`, `create_time`, `update_time`, `delete_time`) VALUES
(1, '管理员', 1, 1, '测试管理员', 1685457618, 1685457618, 0),
(6, '游客权限', 0, 1, '', 1685457618, 1685457618, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ul_system_auth_node`
--

CREATE TABLE `ul_system_auth_node` (
  `id` int(11) NOT NULL,
  `auth_id` bigint(20) UNSIGNED NOT NULL COMMENT '角色ID',
  `node_id` bigint(20) UNSIGNED NOT NULL COMMENT '节点ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色与节点关系表';

-- --------------------------------------------------------

--
-- 表的结构 `ul_system_config`
--

CREATE TABLE `ul_system_config` (
  `id` int(11) NOT NULL,
  `name` char(30) NOT NULL DEFAULT '' COMMENT '变量名',
  `group` char(30) NOT NULL DEFAULT '' COMMENT '分组',
  `value` text NOT NULL COMMENT '变量值',
  `remark` char(100) NOT NULL DEFAULT '' COMMENT '备注信息',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统配置表';

--
-- 转存表中的数据 `ul_system_config`
--

INSERT INTO `ul_system_config` (`id`, `name`, `group`, `value`, `remark`, `sort`, `create_time`, `update_time`) VALUES
(1, 'base_admin_install', 'system', '1', '系统初始化锁定，请勿修改，避免插入重复数据', 0, 1685457618, 1685457618),
(2, 'alisms_access_key_id', 'sms', '填你的', '阿里大于公钥', 0, 1685457618, 1685457618),
(3, 'alisms_access_key_secret', 'sms', '填你的', '阿里大鱼私钥', 0, 1685457618, 1685457618),
(4, 'upload_type', 'upload', 'local_public', '当前上传方式 local_public,alioss,qnoss,txoss）', 0, 1685457618, 1685457618),
(5, 'upload_allow_ext', 'upload', 'jpg,jpeg,png,gif,bmp,doc,docx,xls,xlsx,ppt,pptx,pdf,zip,rar,7z,txt,mp3,wma,wav,mid,m4a,mp4,avi,wmv,3gp,flv,webp,svg,ico', '允许上传的文件类型', 0, 1685457618, 1685457618),
(6, 'upload_allow_size', 'upload', '1024000', '允许上传的大小', 0, 1685457618, 1685457618),
(7, 'upload_allow_mime', 'upload', 'image/gif,image/jpeg,video/x-msvideo,text/plain,image/png', '允许上传的文件mime', 0, 1685457618, 1685457618),
(8, 'upload_allow_type', 'upload', 'local_public,alioss,qnoss,txcos', '可用的上传文件方式', 0, 1685457618, 1685457618),
(9, 'alioss_access_key_id', 'upload', '填你的', '阿里云oss公钥', 0, 1685457618, 1685457618),
(10, 'alioss_access_key_secret', 'upload', '填你的', '阿里云oss私钥', 0, 1685457618, 1685457618),
(11, 'alioss_endpoint', 'upload', '填你的', '阿里云oss数据中心', 0, 1685457618, 1685457618),
(12, 'alioss_bucket', 'upload', '填你的', '阿里云oss空间名称', 0, 1685457618, 1685457618),
(13, 'alioss_domain', 'upload', '填你的', '阿里云oss访问域名', 0, 1685457618, 1685457618),
(14, 'logo_title', 'site', 'AI网址导航-SSLPHP', 'LOGO标题', 0, 1685457618, 1685457618),
(15, 'logo_image', 'site', '/storage/upload/20230531/64763f793852c.png', 'logo图片', 0, 1685457618, 1685457618),
(16, 'site_keywords', 'site', 'AI导航,SSLPHP,AI工具,AI导航,AI人工智能,AI绘画,AI智能对话,AI翻译,AI提示词,AI工具,AI智能写作,AI 3D设计,AI视频,AI语音,AI资讯,AI资源,AI开源', 'SEO关键字', 0, 1685457618, 1685497153),
(17, 'site_ico', 'site', '/storage/upload/20230531/64763f8fe7724.ico', '浏览器图标', 0, 1685457618, 1685471125),
(18, 'site_copyright', 'site', 'SSLPHP', '版权信息', 0, 1685457618, 1685471483),
(19, 'site_beian', 'site', '闽ICP备17021618号-3', '备案信息', 0, 1685457618, 1685471483),
(20, 'site_version', 'site', '2.0.0', '版本信息', 0, 1685457618, 1685457618),
(21, 'sms_type', 'sms', 'alisms', '短信类型', 0, 1685457618, 1685457618),
(22, 'miniapp_appid', 'wechat', '填你的', '小程序公钥', 0, 1685457618, 1685457618),
(23, 'miniapp_appsecret', 'wechat', '填你的', '小程序私钥', 0, 1685457618, 1685457618),
(24, 'web_appid', 'wechat', '填你的', '公众号公钥', 0, 1685457618, 1685457618),
(25, 'web_appsecret', 'wechat', '填你的', '公众号私钥', 0, 1685457618, 1685457618),
(26, 'txcos_secret_id', 'upload', '填你的', '腾讯云cos密钥', 0, 1685457618, 1685457618),
(27, 'txcos_secret_key', 'upload', '填你的', '腾讯云cos私钥', 0, 1685457618, 1685457618),
(28, 'txcos_region', 'upload', '填你的', '存储桶地域', 0, 1685457618, 1685457618),
(29, 'txcos_bucket', 'upload', '填你的', '存储桶名称', 0, 1685457618, 1685457618),
(30, 'qnoss_access_key', 'upload', '填你的', '访问密钥', 0, 1685457618, 1685457618),
(31, 'qnoss_secret_key', 'upload', '填你的', '安全密钥', 0, 1685457618, 1685457618),
(32, 'qnoss_bucket', 'upload', '填你的', '存储空间', 0, 1685457618, 1685457618),
(33, 'qnoss_domain', 'upload', '填你的', '访问域名', 0, 1685457618, 1685457618),
(34, 'txcos_domain', 'upload', '填你的', '访问域名', 0, 1685457618, 1685457618),
(35, 'txcos_appid', 'upload', '填你的', 'APPID', 0, 1685457618, 1685457618),
(36, 'file', 'site', '', '', 0, 1685457618, 1685457618),
(37, 'site_domain', 'site', 'http://', '', 0, 1685457618, 1685471186),
(38, 'site_default_password', 'site', '', '', 0, 1685471125, 1685471125),
(39, 'site_js_insert', 'site', '', '', 0, 1685471125, 1685471125),
(40, 'site_description', 'site', 'SSLPHP-AI导航是SSLPHP网旗下专业全面的AI人工智能导航网站！SSLphp导航为AI创作者提供AI绘画、AI智能对话、AI翻译、AI提示词、AI工具、AI智能写作、AI 3D设计、AI视频、AI语音等AI网站导航指引。', '网站描述', 0, 1685457618, 1685497056),
(41, 'site_name', 'site', 'AI网址导航-SSLPHP网址导航', '', 0, 1685496952, 1685497038),
(42, 'w_image', 'site', '/storage/upload/20230531/6476d2334a4ef.jpg', '微信公众号图片', 0, 1685457618, 1685457618),
(43, 'site_weibourl', 'site', 'http://ssl.goolibao.com', '微博链接', 0, 1685457618, 1685509115),
(44, 'site_xiaohongshuurl', 'site', 'http://ssl.goolibao.com', '小红书链接', 0, 1685457618, 1685509115),
(45, 'site_shangwuurl', 'site', 'http://ssl.goolibao.com', '商务联系链接', 0, 1685457618, 1685509115),
(46, 'wx_image', 'site', 'https://k.goolibao.com/public/v.jpg', '加微信图片', 0, 1685457618, 1685457618),
(47, 'site_yanse', 'site', 'rgba(65,127,249,0.9)', '导航颜色', 0, 1685457618, 1685522473),
(48, 'site_yanse2', 'site', '#ff6000', '侧边导航颜色', 0, 1685457618, 1685598955),
(49, 'site_footyanse', 'site', '#000000', '最底部颜色', 0, 1685457618, 1687009627),
(50, 'site_foot-top', 'site', '#ff6000', '底部的头部', 0, 1685457618, 1687009782),
(51, 'site_foot-zi', 'site', '#ffffff', '底部字体颜色', 0, 1685457618, 1687009656);

-- --------------------------------------------------------

--
-- 表的结构 `ul_system_menu`
--

CREATE TABLE `ul_system_menu` (
  `id` int(11) NOT NULL,
  `pid` bigint(20) UNSIGNED NOT NULL DEFAULT '0' COMMENT '父id',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '名称',
  `icon` char(100) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `href` char(100) NOT NULL DEFAULT '' COMMENT '链接',
  `auth_node` char(100) NOT NULL DEFAULT '' COMMENT '权限标志',
  `params` text NOT NULL COMMENT '链接参数',
  `target` char(20) NOT NULL DEFAULT '_self' COMMENT '链接打开方式',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '状态 {radio} (0:禁用,1:启用)',
  `remark` char(255) NOT NULL DEFAULT '' COMMENT '备注说明',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统菜单表';

--
-- 转存表中的数据 `ul_system_menu`
--

INSERT INTO `ul_system_menu` (`id`, `pid`, `title`, `icon`, `href`, `auth_node`, `params`, `target`, `sort`, `status`, `remark`, `create_time`, `update_time`, `delete_time`) VALUES
(227, 99999999, '后台首页', 'fa fa-home', 'index/welcome', '', '', '_self', 0, 1, '', 1685457618, 1685457618, 0),
(228, 0, '系统管理', 'fa fa-cog', '', '', '', '_self', 0, 1, '', 1685457618, 1685457618, 0),
(234, 228, '菜单管理', 'fa fa-tree', 'system.menu/index', '', '', '_self', 10, 1, '', 1685457618, 1685457618, 0),
(244, 228, '管理员管理', 'fa fa-user', 'system.admin/index', '', '', '_self', 12, 1, '', 1685457618, 1685457618, 0),
(245, 228, '角色管理', 'fa fa-bitbucket-square', 'system.auth/index', '', '', '_self', 11, 1, '', 1685457618, 1685457618, 0),
(246, 228, '节点管理', 'fa fa-list', 'system.node/index', '', '', '_self', 9, 1, '', 1685457618, 1685457618, 0),
(247, 228, '配置管理', 'fa fa-asterisk', 'system.config/index', '', '', '_self', 8, 1, '', 1685457618, 1685457618, 0),
(248, 228, '上传管理', 'fa fa-arrow-up', 'system.uploadfile/index', '', '', '_self', 0, 1, '', 1685457618, 1685457618, 0),
(249, 0, 'AI导航管理', 'fa fa-list', '', '', '', '_self', 0, 1, '', 1685457618, 1685458237, 0),
(250, 249, 'AI导航分类', 'fa fa-calendar-check-o', 'mall.cate/index', '', '', '_self', 0, 1, '', 1685457618, 1685458262, 0),
(251, 249, '内容管理', 'fa fa-list', 'mall.goods/index', '', '', '_self', 0, 1, '', 1685457618, 1685459385, 0),
(252, 228, '快捷入口', 'fa fa-list', 'system.quick/index', '', '', '_self', 0, 1, '', 1685457618, 1685457618, 0),
(253, 228, '日志管理', 'fa fa-connectdevelop', 'debug.log/index', '', '', '_self', 0, 1, '', 1685457618, 1685457618, 0),
(254, 249, '导航标签', 'fa fa-connectdevelop', 'mall.tag/index', '', '', '_self', 0, 1, '', 1685457618, 1685458291, 0),
(255, 0, 'SSLPHP网址AI导航', 'fa fa-list', '', '', '', '_self', 0, 1, '', 1685457618, 1685497679, 0),
(256, 255, 'AI导航分类', 'fa fa-calendar-check-o', 'mallt.cate/index', '', '', '_self', 0, 1, '', 1685457618, 1685458262, 0),
(257, 0, '友情链接管理', 'fa fa-list', '', '', '', '_self', 0, 1, '', 1685457618, 1685458237, 0),
(258, 257, '链接管理', 'fa fa-calendar-check-o', 'flink/index', '', '', '_self', 0, 1, '', 1685457618, 1685458262, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ul_system_node`
--

CREATE TABLE `ul_system_node` (
  `id` int(11) NOT NULL,
  `node` char(100) NOT NULL DEFAULT '' COMMENT '节点代码',
  `title` char(255) NOT NULL DEFAULT '' COMMENT '节点标题',
  `type` int(1) UNSIGNED NOT NULL COMMENT '节点类型（1：控制器，2：节点）',
  `is_auth` int(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT '是否启动RBAC权限控制',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统节点表';

--
-- 转存表中的数据 `ul_system_node`
--

INSERT INTO `ul_system_node` (`id`, `node`, `title`, `type`, `is_auth`, `create_time`, `update_time`) VALUES
(1, 'system.admin', '管理员管理', 1, 1, 1657347263, 1657347263),
(2, 'system.admin/index', '列表', 2, 1, 1657347263, 1657347263),
(3, 'system.admin/add', '添加', 2, 1, 1657347263, 1657347263),
(4, 'system.admin/edit', '编辑', 2, 1, 1657347263, 1657347263),
(5, 'system.admin/password', '编辑', 2, 1, 1657347263, 1657347263),
(6, 'system.admin/delete', '删除', 2, 1, 1657347263, 1657347263),
(7, 'system.admin/modify', '属性修改', 2, 1, 1657347263, 1657347263),
(8, 'system.admin/export', '导出', 2, 1, 1657347264, 1657347264),
(9, 'system.auth', '角色权限管理', 1, 1, 1657347264, 1657347264),
(10, 'system.auth/authorize', '授权', 2, 1, 1657347264, 1657347264),
(11, 'system.auth/saveAuthorize', '授权保存', 2, 1, 1657347264, 1657347264),
(12, 'system.auth/index', '列表', 2, 1, 1657347264, 1657347264),
(13, 'system.auth/add', '添加', 2, 1, 1657347264, 1657347264),
(14, 'system.auth/edit', '编辑', 2, 1, 1657347264, 1657347264),
(15, 'system.auth/delete', '删除', 2, 1, 1657347265, 1657347265),
(16, 'system.auth/export', '导出', 2, 1, 1657347265, 1657347265),
(17, 'system.auth/modify', '属性修改', 2, 1, 1657347265, 1657347265),
(18, 'system.config', '系统配置管理', 1, 1, 1657347265, 1657347265),
(19, 'system.config/index', '列表', 2, 1, 1657347265, 1657347265),
(20, 'system.config/save', '保存', 2, 1, 1657347265, 1657347265),
(21, 'system.menu', '菜单管理', 1, 1, 1657347265, 1657347265),
(22, 'system.menu/index', '列表', 2, 1, 1657347265, 1657347265),
(23, 'system.menu/add', '添加', 2, 1, 1657347266, 1657347266),
(24, 'system.menu/edit', '编辑', 2, 1, 1657347266, 1657347266),
(25, 'system.menu/delete', '删除', 2, 1, 1657347266, 1657347266),
(26, 'system.menu/modify', '属性修改', 2, 1, 1657347266, 1657347266),
(27, 'system.menu/getMenuTips', '添加菜单提示', 2, 1, 1657347266, 1657347266),
(28, 'system.menu/export', '导出', 2, 1, 1657347266, 1657347266),
(29, 'system.node', '系统节点管理', 1, 1, 1657347266, 1657347266),
(30, 'system.node/index', '列表', 2, 1, 1657347266, 1657347266),
(31, 'system.node/refreshNode', '系统节点更新', 2, 1, 1657347267, 1657347267),
(32, 'system.node/clearNode', '清除失效节点', 2, 1, 1657347267, 1657347267),
(33, 'system.node/add', '添加', 2, 1, 1657347267, 1657347267),
(34, 'system.node/edit', '编辑', 2, 1, 1657347267, 1657347267),
(35, 'system.node/delete', '删除', 2, 1, 1657347267, 1657347267),
(36, 'system.node/export', '导出', 2, 1, 1657347267, 1657347267),
(37, 'system.node/modify', '属性修改', 2, 1, 1657347267, 1657347267),
(38, 'system.uploadfile', '上传文件管理', 1, 1, 1657347268, 1657347268),
(39, 'system.uploadfile/index', '列表', 2, 1, 1657347268, 1657347268),
(40, 'system.uploadfile/add', '添加', 2, 1, 1657347268, 1657347268),
(41, 'system.uploadfile/edit', '编辑', 2, 1, 1657347268, 1657347268),
(42, 'system.uploadfile/delete', '删除', 2, 1, 1657347268, 1657347268),
(43, 'system.uploadfile/export', '导出', 2, 1, 1657347268, 1657347268),
(44, 'system.uploadfile/modify', '属性修改', 2, 1, 1657347268, 1657347268),
(45, 'mall.cate', '分类管理', 1, 1, 1657347268, 1685496194),
(46, 'mall.cate/index', '列表', 2, 1, 1657347269, 1657347269),
(47, 'mall.cate/add', '添加', 2, 1, 1657347269, 1657347269),
(48, 'mall.cate/edit', '编辑', 2, 1, 1657347269, 1657347269),
(49, 'mall.cate/delete', '删除', 2, 1, 1657347269, 1657347269),
(50, 'mall.cate/export', '导出', 2, 1, 1657347269, 1657347269),
(51, 'mall.cate/modify', '属性修改', 2, 1, 1657347269, 1657347269),
(52, 'mall.goods', '导航管理', 1, 1, 1657347269, 1685496163),
(53, 'mall.goods/index', '列表', 2, 1, 1657347270, 1657347270),
(54, 'mall.goods/stock', '入库', 2, 1, 1657347270, 1657347270),
(55, 'mall.goods/add', '添加', 2, 1, 1657347270, 1657347270),
(56, 'mall.goods/edit', '编辑', 2, 1, 1657347270, 1657347270),
(57, 'mall.goods/delete', '删除', 2, 1, 1657347270, 1657347270),
(58, 'mall.goods/export', '导出', 2, 1, 1657347270, 1657347270),
(59, 'mall.goods/modify', '属性修改', 2, 1, 1657347270, 1657347270),
(60, 'system.quick', '快捷入口管理', 1, 1, 1657347270, 1657347270),
(61, 'system.quick/index', '列表', 2, 1, 1657347271, 1657347271),
(62, 'system.quick/add', '添加', 2, 1, 1657347271, 1657347271),
(63, 'system.quick/edit', '编辑', 2, 1, 1657347271, 1657347271),
(64, 'system.quick/delete', '删除', 2, 1, 1657347271, 1657347271),
(65, 'system.quick/export', '导出', 2, 1, 1657347271, 1657347271),
(66, 'system.quick/modify', '属性修改', 2, 1, 1657347271, 1657347271),
(69, 'debug.log', 'debug_log', 1, 1, 1657347271, 1657347271),
(70, 'debug.log/index', '列表', 2, 1, 1657347272, 1657347272),
(71, 'debug.log/add', '添加', 2, 1, 1657347272, 1657347272),
(72, 'debug.log/edit', '编辑', 2, 1, 1657347272, 1657347272),
(73, 'debug.log/delete', '删除', 2, 1, 1657347272, 1657347272),
(74, 'debug.log/export', '导出', 2, 1, 1657347272, 1657347272),
(75, 'debug.log/modify', '属性修改', 2, 1, 1657347272, 1657347272),
(76, 'mall.tag', 'mall_tag', 1, 1, 1657347614, 1657347614),
(77, 'mall.tag/index', '列表', 2, 1, 1657347614, 1657347614),
(78, 'mall.tag/add', '添加', 2, 1, 1657347615, 1657347615),
(79, 'mall.tag/edit', '编辑', 2, 1, 1657347615, 1657347615),
(80, 'mall.tag/delete', '删除', 2, 1, 1657347615, 1657347615),
(81, 'mall.tag/export', '导出', 2, 1, 1657347615, 1657347615),
(82, 'mall.tag/modify', '属性修改', 2, 1, 1657347615, 1657347615),
(83, 'mallt.goods', 'SSLPHP导航管理', 1, 1, 1657347269, 1685496163),
(84, 'mallt.goods/index', '列表', 2, 1, 1657347270, 1657347270),
(85, 'mallt.goods/stock', '入库', 2, 1, 1657347270, 1657347270),
(86, 'mallt.goods/add', '添加', 2, 1, 1657347270, 1657347270),
(87, 'mallt.goods/edit', '编辑', 2, 1, 1657347270, 1657347270),
(88, 'mallt.goods/delete', '删除', 2, 1, 1657347270, 1657347270),
(89, 'mallt.goods/export', '导出', 2, 1, 1657347270, 1657347270),
(90, 'mallt.goods/modify', '属性修改', 2, 1, 1657347270, 1657347270),
(91, 'mallt.cate', 'sslphpAI导航分类管理', 1, 1, 1657347268, 1685496194),
(92, 'mall.cate/index', '列表', 2, 1, 1657347269, 1657347269),
(93, 'mallt.cate/add', '添加', 2, 1, 1657347269, 1657347269),
(94, 'mallt.cate/edit', '编辑', 2, 1, 1657347269, 1657347269),
(95, 'mallt.cate/delete', '删除', 2, 1, 1657347269, 1657347269),
(96, 'mallt.cate/export', '导出', 2, 1, 1657347269, 1657347269),
(97, 'mallt.cate/modify', '属性修改', 2, 1, 1657347269, 1657347269);

-- --------------------------------------------------------

--
-- 表的结构 `ul_system_quick`
--

CREATE TABLE `ul_system_quick` (
  `id` int(11) NOT NULL,
  `title` char(20) NOT NULL DEFAULT '' COMMENT '快捷入口名称',
  `icon` char(100) NOT NULL DEFAULT '' COMMENT '图标',
  `href` char(255) NOT NULL COMMENT '快捷链接',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` int(1) UNSIGNED NOT NULL COMMENT '状态 {radio} (1:禁用,2:启用)',
  `remark` char(255) NOT NULL DEFAULT '' COMMENT '备注说明',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统快捷入口表';

--
-- 转存表中的数据 `ul_system_quick`
--

INSERT INTO `ul_system_quick` (`id`, `title`, `icon`, `href`, `sort`, `status`, `remark`, `create_time`, `update_time`, `delete_time`) VALUES
(1, '管理员管理', 'fa fa-user', 'system.admin/index', 0, 1, '', 1685457618, 1685457618, 0),
(2, '角色管理', 'fa fa-bitbucket-square', 'system.auth/index', 0, 1, '', 1685457618, 1685457618, 0),
(3, '菜单管理', 'fa fa-tree', 'system.menu/index', 0, 1, '', 1685457618, 1685457618, 0),
(4, '节点管理', 'fa fa-list', 'system.node/index', 0, 1, '', 1685457618, 1685457618, 0),
(5, '配置管理', 'fa fa-asterisk', 'system.config/index', 0, 1, '', 1685457618, 1685457618, 0),
(6, '上传管理', 'fa fa-arrow-up', 'system.uploadfile/index', 0, 1, '', 1685457618, 1685457618, 0),
(7, '分类管理', 'fa fa-calendar-check-o', 'mall.cate/index', 0, 1, '', 1685457618, 1685460911, 0),
(8, '内容管理', 'fa fa-list', 'mall.goods/index', 0, 1, '', 1685457618, 1685460900, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ul_system_uploadfile`
--

CREATE TABLE `ul_system_uploadfile` (
  `id` int(11) NOT NULL,
  `upload_type` char(20) NOT NULL DEFAULT 'local' COMMENT '存储位置',
  `original_name` char(255) NOT NULL DEFAULT '' COMMENT '文件原名',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接',
  `save_name` char(255) NOT NULL DEFAULT '' COMMENT '存储名称',
  `image_width` char(30) NOT NULL DEFAULT '' COMMENT '宽度',
  `image_height` char(30) NOT NULL DEFAULT '' COMMENT '高度',
  `image_frames` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '图片帧数',
  `mime_type` char(100) NOT NULL DEFAULT '' COMMENT 'mime类型',
  `file_size` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '文件大小',
  `file_ext` char(100) NOT NULL DEFAULT '' COMMENT '扩展名',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='上传文件表';

--
-- 转存表中的数据 `ul_system_uploadfile`
--

INSERT INTO `ul_system_uploadfile` (`id`, `upload_type`, `original_name`, `url`, `save_name`, `image_width`, `image_height`, `image_frames`, `mime_type`, `file_size`, `file_ext`, `sha1`, `create_time`, `update_time`, `delete_time`) VALUES
(1, 'local_public', 'AI.png', 'http://127.0.0.3/storage/upload/20230530/6476128e23b5d.png', 'upload/20230530/6476128e23b5d.png', '', '', 0, 'image/png', 2283, 'png', '617289def3585878c3fd2ab82baf23c96c203efa', 1685459598, 1685459598, 0),
(2, 'local_public', 'AI及算法.png', 'http://127.0.0.3/storage/upload/20230530/647612c88b565.png', 'upload/20230530/647612c88b565.png', '', '', 0, 'image/png', 1638, 'png', 'ebf57fe16ce09efa462856091ceda20b4cb12960', 1685459656, 1685459656, 0),
(3, 'local_public', 'ai辅助审片.png', 'http://127.0.0.3/storage/upload/20230530/647612f50faf4.png', 'upload/20230530/647612f50faf4.png', '', '', 0, 'image/png', 2651, 'png', '6eeb18b15c25b485755707d8e62b7c3571870e95', 1685459701, 1685459701, 0),
(4, 'local_public', 'www.notion.so.ico', 'http://127.0.0.3/storage/upload/20230530/647613a8291da.ico', 'upload/20230530/647613a8291da.ico', '', '', 0, 'image/x-icon', 2647, 'ico', '5aa05da5efa515d5db734992c5ebca49df945095', 1685459880, 1685459880, 0),
(5, 'local_public', 'www.notion.jpg', 'http://127.0.0.3/storage/upload/20230530/647613c2b603c.jpg', 'upload/20230530/647613c2b603c.jpg', '', '', 0, 'image/jpeg', 39847, 'jpg', '6c9c5e08c7bfefca89f37ad7456080d8846867f1', 1685459906, 1685459906, 0),
(6, 'local_public', 'SSL.png', 'http://127.0.0.3/storage/upload/20230531/64763f793852c.png', 'upload/20230531/64763f793852c.png', '', '', 0, 'image/png', 8364, 'png', '411dc7a0f27eb5183201f8bbc618840d3271bb52', 1685471097, 1685471097, 0),
(7, 'local_public', 'favicon.ico', 'http://127.0.0.3/storage/upload/20230531/64763f8fe7724.ico', 'upload/20230531/64763f8fe7724.ico', '', '', 0, 'image/x-icon', 1150, 'ico', 'df34f60a4001bdcb8c2ab15cd50c92feb6288a31', 1685471119, 1685471119, 0),
(8, 'local_public', 'gh_e45b98214fde_258.jpg', 'http://127.0.0.3/storage/upload/20230531/6476d13eec56a.jpg', 'upload/20230531/6476d13eec56a.jpg', '', '', 0, 'image/jpeg', 45675, 'jpg', '649d6945347b3da8d6f027d6222a0bb76f3de563', 1685508414, 1685508414, 0),
(9, 'local_public', 'qrcode_for_gh_954e1dc67232_258.jpg', 'http://127.0.0.3/storage/upload/20230531/6476d2334a4ef.jpg', 'upload/20230531/6476d2334a4ef.jpg', '', '', 0, 'image/jpeg', 27666, 'jpg', '6d644fad93878487865f3059d4127ce2963601ba', 1685508659, 1685508659, 0),
(10, 'local_public', 'nav-ai-Midjourney.png', 'http://127.0.0.3/storage/upload/20230531/6476ed6c309ee.png', 'upload/20230531/6476ed6c309ee.png', '', '', 0, 'image/png', 1281, 'png', '0156bc97e442e665f6680e37ad8df6c05f8406d6', 1685515628, 1685515628, 0),
(11, 'local_public', 'nav-ai-ChatGPT.png', 'http://127.0.0.3/storage/upload/20230531/6476edc3a0c86.png', 'upload/20230531/6476edc3a0c86.png', '', '', 0, 'image/png', 1092, 'png', '82abeb5a2900fc8e4cca16d5baff08f9452aa2f5', 1685515715, 1685515715, 0),
(12, 'local_public', 'nav-ai-stable.png', 'http://127.0.0.3/storage/upload/20230531/6476ee443642f.png', 'upload/20230531/6476ee443642f.png', '', '', 0, 'image/png', 1649, 'png', '42ce9f28973aadb9d24e0f2b8ca084d2717a48af', 1685515844, 1685515844, 0),
(13, 'local_public', 'nav-ai-NijiJourney.png', 'http://127.0.0.3/storage/upload/20230531/6476eee1b4523.png', 'upload/20230531/6476eee1b4523.png', '', '', 0, 'image/png', 1577, 'png', 'cdf73fc8717ab1122e2297a990432aa5701c9c68', 1685516001, 1685516001, 0),
(14, 'local_public', 'nav-ai-microsoftdesign.png', 'http://127.0.0.3/storage/upload/20230531/6476ef407cfd1.png', 'upload/20230531/6476ef407cfd1.png', '', '', 0, 'image/png', 2470, 'png', '4a96b073c675433817d74f9f4df0a2b79fbf9104', 1685516096, 1685516096, 0),
(15, 'local_public', 'nav-ai-HuggingFace.png', 'http://127.0.0.3/storage/upload/20230531/6476efb8bf585.png', 'upload/20230531/6476efb8bf585.png', '', '', 0, 'image/png', 842, 'png', '0dc6f40c1bf572e6bcf1795f8746f5b5415108a0', 1685516216, 1685516216, 0),
(16, 'local_public', 'nav-ai-saas.png', 'http://127.0.0.3/storage/upload/20230531/6476f04b72a3b.png', 'upload/20230531/6476f04b72a3b.png', '', '', 0, 'image/png', 1339, 'png', 'cffed10fcf98d9e3604e0cace74954da464a8b9e', 1685516363, 1685516363, 0),
(17, 'local_public', 'nav-ai-PromptHero.png', 'http://127.0.0.3/storage/upload/20230531/6476f1c3f10ab.png', 'upload/20230531/6476f1c3f10ab.png', '', '', 0, 'image/png', 3243, 'png', '1229fcee681e75b7c8f705f29ab08a095209df78', 1685516740, 1685516740, 0),
(18, 'local_public', 'nav-ai-vectorizer.png', 'http://127.0.0.3/storage/upload/20230531/6476f23c714fd.png', 'upload/20230531/6476f23c714fd.png', '', '', 0, 'image/png', 502, 'png', 'e2eee5bb177cc973cd2fdd9ad4f0f3a177b85257', 1685516860, 1685516860, 0),
(19, 'local_public', 'nav-ai-Runway.png', 'http://127.0.0.3/storage/upload/20230531/6476f27e3dfb3.png', 'upload/20230531/6476f27e3dfb3.png', '', '', 0, 'image/png', 1462, 'png', '923a77e17de65ffa64bd6338f08d1620b2c79181', 1685516926, 1685516926, 0),
(20, 'local_public', 'SSL认证.png', 'http://127.0.0.3/storage/upload/20230531/6476f2f875207.png', 'upload/20230531/6476f2f875207.png', '', '', 0, 'image/png', 4938, 'png', 'd8e3c89d776c2cb7823c2d389ce5417c1244f13a', 1685517048, 1685517048, 0),
(21, 'local_public', 'nav-ai-ChatGPT.png', 'http://127.0.0.3/storage/upload/20230531/6476f71aa9996.png', 'upload/20230531/6476f71aa9996.png', '', '', 0, 'image/png', 1092, 'png', '82abeb5a2900fc8e4cca16d5baff08f9452aa2f5', 1685518106, 1685518106, 0),
(22, 'local_public', 'nav-ai-Anthropi.png', 'http://127.0.0.3/storage/upload/20230531/6476f7497c855.png', 'upload/20230531/6476f7497c855.png', '', '', 0, 'image/png', 901, 'png', '8e271e5c1d9b4b2294628e809616671783770415', 1685518153, 1685518153, 0),
(23, 'local_public', 'nav-ai-OpenCat.png', 'http://127.0.0.3/storage/upload/20230531/6476f7f905943.png', 'upload/20230531/6476f7f905943.png', '', '', 0, 'image/png', 3242, 'png', 'e5b80afa44ff885e697564a96335a3cf233d0dc6', 1685518329, 1685518329, 0),
(24, 'local_public', 'nav-ai-newbing.png', 'http://127.0.0.3/storage/upload/20230531/6476f841d6aa0.png', 'upload/20230531/6476f841d6aa0.png', '', '', 0, 'image/png', 2663, 'png', 'dd77e6f02e6d2b64f6642765e89e279288b17ad9', 1685518401, 1685518401, 0),
(25, 'local_public', 'nav-ai-tongyi.png', 'http://127.0.0.3/storage/upload/20230531/6476f8a35337e.png', 'upload/20230531/6476f8a35337e.png', '', '', 0, 'image/png', 2271, 'png', 'dfb2eeb8b82e7c1b990b73af9788e69c0311bfa0', 1685518499, 1685518499, 0),
(26, 'local_public', 'nav-ai-YOU.png', 'http://127.0.0.3/storage/upload/20230531/6476f916f002e.png', 'upload/20230531/6476f916f002e.png', '', '', 0, 'image/png', 2525, 'png', '9b194d3ef860409df3d8460f1bb057732415ca87', 1685518614, 1685518614, 0),
(27, 'local_public', 'nav-ai-Midjourney.png', 'http://127.0.0.3/storage/upload/20230531/64770a3bee6a7.png', 'upload/20230531/64770a3bee6a7.png', '', '', 0, 'image/png', 1281, 'png', '0156bc97e442e665f6680e37ad8df6c05f8406d6', 1685523003, 1685523003, 0),
(28, 'local_public', 'nav-ai-stable.png', 'http://127.0.0.3/storage/upload/20230531/64770a77be545.png', 'upload/20230531/64770a77be545.png', '', '', 0, 'image/png', 1649, 'png', '42ce9f28973aadb9d24e0f2b8ca084d2717a48af', 1685523063, 1685523063, 0),
(29, 'local_public', 'nav-ai-wxyg.png', 'http://127.0.0.3/storage/upload/20230531/64770b0f6c540.png', 'upload/20230531/64770b0f6c540.png', '', '', 0, 'image/png', 483, 'png', 'e61a174da1bccccf8c71d55a6b2c48a01e8f6b29', 1685523215, 1685523215, 0),
(30, 'local_public', 'nav-ai-Dreamlike.png', 'http://127.0.0.3/storage/upload/20230531/64770b5084823.png', 'upload/20230531/64770b5084823.png', '', '', 0, 'image/png', 344, 'png', '27e3159533eb35c6a3585d2b379d2486171c6377', 1685523280, 1685523280, 0),
(31, 'local_public', 'nav-ai-DALLE2.png', 'http://127.0.0.3/storage/upload/20230531/64770ba57f365.png', 'upload/20230531/64770ba57f365.png', '', '', 0, 'image/png', 2769, 'png', 'a486173d6bac466f31a6ef2ee1c1f169c71e1515', 1685523365, 1685523365, 0),
(32, 'local_public', 'nav-ai-HuggingFace.png', 'http://127.0.0.3/storage/upload/20230531/64770bfaad411.png', 'upload/20230531/64770bfaad411.png', '', '', 0, 'image/png', 842, 'png', '0dc6f40c1bf572e6bcf1795f8746f5b5415108a0', 1685523450, 1685523450, 0),
(33, 'local_public', 'nav-ai-Noonshot.png', 'http://127.0.0.3/storage/upload/20230531/64771acccbf5c.png', 'upload/20230531/64771acccbf5c.png', '', '', 0, 'image/png', 1741, 'png', '2279282360a06d629c55d7898c66887ca4a2d808', 1685527244, 1685527244, 0),
(34, 'local_public', 'avatar.png', 'http://127.0.0.3/storage/upload/20230531/64775f5209841.png', 'upload/20230531/64775f5209841.png', '', '', 0, 'image/png', 27333, 'png', '75de70fd8c61d726e58961e6cf85a1c1fa8c8103', 1685544786, 1685544786, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ul_test_goods`
--

CREATE TABLE `ul_test_goods` (
  `id` int(11) NOT NULL,
  `cate_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0' COMMENT '分类ID {relation} (table:mall_cate,relationBindSelect:title)',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '名称',
  `logo` char(255) NOT NULL COMMENT 'logo {image}',
  `images` text NOT NULL COMMENT '图片 {images}',
  `describe` text NOT NULL COMMENT '描述 {editor}',
  `total_stock` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '总库存',
  `sort` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '排序',
  `status` int(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '状态 {radio} (0:正常,1:禁用)',
  `cert_file` varchar(100) NOT NULL COMMENT '合格证 {file}',
  `verfiy_file` text NOT NULL COMMENT '检测报告 {files}',
  `remark` char(255) NOT NULL DEFAULT '' COMMENT '备注说明',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `delete_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `publish_time` int(10) UNSIGNED NOT NULL COMMENT '发布日期 {date} (date)',
  `sale_time` bigint(20) UNSIGNED NOT NULL COMMENT '售卖日期 {date} (datetime)',
  `intro` varchar(100) NOT NULL COMMENT '简介 {textarea}',
  `time_status` int(5) UNSIGNED NOT NULL COMMENT '秒杀状态 {select} (0:未参加,1:已开始,3:已结束)',
  `is_recommend` int(4) NOT NULL COMMENT '是否推荐 {switch} (0:不推荐,1:推荐)',
  `shop_type` varchar(100) NOT NULL COMMENT '商品类型 {checkbox} (taobao:淘宝,jd:京东)',
  `tag` varchar(100) NOT NULL COMMENT '商品标签 {table} (table:mall_tag,type:checkbox,valueField:id,fieldName:title)',
  `tag_backup` varchar(100) DEFAULT NULL COMMENT '商品标签（单选） {table} (table:mall_tag,type:radio,valueField:id,fieldName:title)',
  `from_area` varchar(100) NOT NULL COMMENT '产地 {city} (name-province:0,code:0)',
  `store_city` varchar(100) NOT NULL DEFAULT '山东省/临沂市' COMMENT '仓库 {city} (level:city)',
  `tag_input` varchar(100) NOT NULL COMMENT '商品标签 （输入） {tag}',
  `uid` varchar(100) NOT NULL COMMENT '唯一id',
  `price` decimal(10,2) DEFAULT NULL COMMENT '价格',
  `detail` text COMMENT '详情'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品列表';

--
-- 转储表的索引
--

--
-- 表的索引 `ul_debug_log`
--
ALTER TABLE `ul_debug_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`);

--
-- 表的索引 `ul_flink`
--
ALTER TABLE `ul_flink`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `ul_mallt_cate`
--
ALTER TABLE `ul_mallt_cate`
  ADD PRIMARY KEY (`id`),
  ADD KEY `title` (`title`),
  ADD KEY `delete_time` (`delete_time`);

--
-- 表的索引 `ul_mall_cate`
--
ALTER TABLE `ul_mall_cate`
  ADD PRIMARY KEY (`id`),
  ADD KEY `title` (`title`),
  ADD KEY `delete_time` (`delete_time`);

--
-- 表的索引 `ul_mall_goods`
--
ALTER TABLE `ul_mall_goods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cate_id` (`cate_id`),
  ADD KEY `delete_time` (`delete_time`);

--
-- 表的索引 `ul_mall_tag`
--
ALTER TABLE `ul_mall_tag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `delete_time` (`delete_time`);

--
-- 表的索引 `ul_migrations`
--
ALTER TABLE `ul_migrations`
  ADD PRIMARY KEY (`version`);

--
-- 表的索引 `ul_system_admin`
--
ALTER TABLE `ul_system_admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`),
  ADD KEY `phone` (`phone`),
  ADD KEY `delete_time` (`delete_time`);

--
-- 表的索引 `ul_system_auth`
--
ALTER TABLE `ul_system_auth`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`),
  ADD KEY `title_2` (`title`),
  ADD KEY `delete_time` (`delete_time`);

--
-- 表的索引 `ul_system_auth_node`
--
ALTER TABLE `ul_system_auth_node`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auth_id` (`auth_id`),
  ADD KEY `node_id` (`node_id`);

--
-- 表的索引 `ul_system_config`
--
ALTER TABLE `ul_system_config`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `group` (`group`);

--
-- 表的索引 `ul_system_menu`
--
ALTER TABLE `ul_system_menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `title` (`title`),
  ADD KEY `href` (`href`),
  ADD KEY `delete_time` (`delete_time`);

--
-- 表的索引 `ul_system_node`
--
ALTER TABLE `ul_system_node`
  ADD PRIMARY KEY (`id`),
  ADD KEY `node` (`node`);

--
-- 表的索引 `ul_system_quick`
--
ALTER TABLE `ul_system_quick`
  ADD PRIMARY KEY (`id`),
  ADD KEY `delete_time` (`delete_time`);

--
-- 表的索引 `ul_system_uploadfile`
--
ALTER TABLE `ul_system_uploadfile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `upload_type` (`upload_type`),
  ADD KEY `original_name` (`original_name`),
  ADD KEY `delete_time` (`delete_time`);

--
-- 表的索引 `ul_test_goods`
--
ALTER TABLE `ul_test_goods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uid` (`uid`),
  ADD KEY `cate_id` (`cate_id`);
ALTER TABLE `ul_test_goods` ADD FULLTEXT KEY `detail` (`detail`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `ul_debug_log`
--
ALTER TABLE `ul_debug_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `ul_flink`
--
ALTER TABLE `ul_flink`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- 使用表AUTO_INCREMENT `ul_mallt_cate`
--
ALTER TABLE `ul_mallt_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- 使用表AUTO_INCREMENT `ul_mall_cate`
--
ALTER TABLE `ul_mall_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- 使用表AUTO_INCREMENT `ul_mall_goods`
--
ALTER TABLE `ul_mall_goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- 使用表AUTO_INCREMENT `ul_mall_tag`
--
ALTER TABLE `ul_mall_tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `ul_system_admin`
--
ALTER TABLE `ul_system_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `ul_system_auth`
--
ALTER TABLE `ul_system_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用表AUTO_INCREMENT `ul_system_auth_node`
--
ALTER TABLE `ul_system_auth_node`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `ul_system_config`
--
ALTER TABLE `ul_system_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- 使用表AUTO_INCREMENT `ul_system_menu`
--
ALTER TABLE `ul_system_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=259;

--
-- 使用表AUTO_INCREMENT `ul_system_node`
--
ALTER TABLE `ul_system_node`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- 使用表AUTO_INCREMENT `ul_system_quick`
--
ALTER TABLE `ul_system_quick`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用表AUTO_INCREMENT `ul_system_uploadfile`
--
ALTER TABLE `ul_system_uploadfile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- 使用表AUTO_INCREMENT `ul_test_goods`
--
ALTER TABLE `ul_test_goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
